from django.shortcuts import render, redirect
from .models import initialReporting
from .forms import initialReportingForm


def welcome(request):
    return render(request, "Welcome.html")


def load_form(request):
    form = initialReportingForm
    return render(request, "index.html", {'form': form})


def add(request):
    form = initialReportingForm(request.POST)
    form.save()
    return redirect('/show')


def show(request):
    InitialReporting = initialReporting.objects.all
    return render(request, "show.html", {'InitialReporting': InitialReporting})


def edit(request, id):
    InitialReporting = initialReporting.objects.get(id=id)
    return render(request, "edit.html", {'InitialReporting': InitialReporting})


def update(request, id):
    InitialReporting = initialReporting.objects.get(id=id)
    form = initialReportingForm(request.POST, instance=InitialReporting)
    form.save()
    return redirect('/show')


def delete(request, id):
    InitialReporting = initialReporting.objects.get(id=id)
    InitialReporting.delete()
    return redirect('/show')


def search(request):
    given_name = request.POST['name']
    InitialReporting = initialReporting.objects.filter(location__icontains=given_name)
    return render(request, "show.html", {'InitialReporting': InitialReporting})