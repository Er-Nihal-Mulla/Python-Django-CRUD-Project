from django import forms
from .models import initialReporting


class initialReportingForm(forms.ModelForm):
    class Meta:
        model = initialReporting
        fields = "__all__"
