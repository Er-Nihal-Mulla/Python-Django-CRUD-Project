from django.db import models

class initialReporting(models.Model):
    location = models.CharField(max_length=50)
    incedentDescription = models.CharField(max_length=50)
    incidentlocation = models.CharField(max_length=50)
    suspectedCouse = models.CharField(max_length=50)
    immediateActionsTaken = models.CharField(max_length=50)